<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{hhproductcomments}prestashop>hhproductcomments_7a0a9b97344353274550297f7c494aa5'] = 'HH Commentaires';
$_MODULE['<{hhproductcomments}prestashop>hhproductcomments_f7e2f341832a5aad806f713558378e3a'] = 'Affiche le module des commentaires dans le hook displayProductExtraContent';
$_MODULE['<{hhproductcomments}prestashop>hhproductcomments_34e80a799d144cfe4af46815e103f017'] = 'Avis clients';
